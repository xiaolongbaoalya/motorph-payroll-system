package com.compprog1282025.gui;

public class AuthService {
    private static final AuthService instance = new AuthService();

    private AuthService() {
        // private constructor
    }

    public static AuthService getInstance() {
        return instance;
    }

    public boolean authenticate(String username, String password) {
        return "admin".equalsIgnoreCase(username) && "admin123".equals(password) ||
               "employee".equalsIgnoreCase(username) && "emp456".equals(password);
    }

    public String getRole(String username) {
        if ("admin".equalsIgnoreCase(username)) return "admin";
        if ("employee".equalsIgnoreCase(username)) return "employee";
        return null;
    }
}
