package com.compprog1282025.gui;

import com.compprog1282025.auth.UserRole;
import com.compprog1282025.model.Employee;
import com.compprog1282025.model.Attendance;
import com.compprog1282025.model.Compensation;
import com.compprog1282025.model.ContactInfo;
import com.compprog1282025.model.GovernmentID;
import com.compprog1282025.model.Position;
import com.compprog1282025.service.*;
import com.compprog1282025.util.CSVWriter;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

//add this
import java.awt.*;
import java.io.File;
import java.time.YearMonth;
import java.util.List;
import java.awt.Dialog.ModalityType; //add this
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;


public class MainGUI extends JFrame {

    private final EmployeeService employeeService;
    private final AttendanceService attendanceService;
    private final PayrollService payrollService;
    private final List<Employee> employees;

    public MainGUI() {
        // Load data
        DataLoaderService loader = new DataLoaderService();
        loader.loadAllData();

        employees = loader.getEmployees();
        List<Attendance> attendanceRecords = loader.getAttendanceRecords();

        attendanceService = new AttendanceService(attendanceRecords);
        payrollService = new PayrollService(attendanceService);
        employeeService = new EmployeeService(employees);

        initUI();
    }

    private void initUI() {
        setTitle("Payroll System");
        setSize(500, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(245, 248, 250));
        GridBagConstraints gbc = new GridBagConstraints();


        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.weighty = 1.0;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(Box.createVerticalGlue(), gbc);

      
        JLabel label = new JLabel("Login as:");
        label.setFont(new Font("Segoe UI", Font.BOLD, 20));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setForeground(new Color(33, 37, 41));
        gbc.gridy = 1;
        gbc.weighty = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        panel.add(label, gbc);

        // Buttons
        JButton employeeBtn = new JButton("Employee");
        JButton adminBtn = new JButton("Admin");
        styleButton(employeeBtn);
        styleButton(adminBtn);
        employeeBtn.setPreferredSize(new Dimension(140, 40));
        adminBtn.setPreferredSize(new Dimension(140, 40));

        employeeBtn.addActionListener(e -> employeeLogin());
        adminBtn.addActionListener(e -> showAdminMenu());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(employeeBtn);
        buttonPanel.add(adminBtn);

        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(buttonPanel, gbc);

        // Add vertical glue after the buttons
        gbc.gridy = 3;
        gbc.weighty = 1.0;
        panel.add(Box.createVerticalGlue(), gbc);

        add(panel);
    }
    
//Change color of the button to 0x1c3680 to match motorPH's logo. We can also add the logo if needed
    private void styleButton(JButton button) {
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(0x1c3680));
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0x1c3680), 1, true),
            BorderFactory.createEmptyBorder(8, 20, 8, 20)
        ));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void styleButtonSmall(JButton button) {
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        button.setBackground(new Color(0x1c3680));
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0x1c3680), 1, true),
            BorderFactory.createEmptyBorder(6, 16, 6, 16)
        ));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

   private void employeeLogin() {
    String input = StyledInputDialog(this, "Employee Login", "Enter your Employee Number:");
    if (input == null) return; // Cancel pressed
    try {
        int empNum = Integer.parseInt(input.trim());
        Employee employee = employeeService.findEmployeeByNumber(empNum);
        if (employee != null) {
            showEmployeeDashboard(employee);
        } else {
            // Use your custom error dialog if you have one, or keep JOptionPane
            StyledErrorDialog(this, "Error", "Employee not found.");
        }
    } catch (NumberFormatException e) {
        StyledErrorDialog(this, "Error", "Invalid employee number.");
    }
}

    private void showEmployeeDashboard(Employee employee) {
        JDialog dialog = new JDialog(this, "Employee Dashboard - " + employee.getFullName(), true);
        dialog.setSize(500, 420);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(10, 10));

        // Header
        JLabel header = new JLabel("Employee Dashboard");
        header.setFont(new Font("Segoe UI", Font.BOLD, 20));
        header.setHorizontalAlignment(SwingConstants.CENTER);
        header.setBorder(BorderFactory.createEmptyBorder(16, 0, 8, 0));
        dialog.add(header, BorderLayout.NORTH);

        
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));
        detailsPanel.setBackground(new Color(245, 248, 250));
        detailsPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 1, true),
            BorderFactory.createEmptyBorder(18, 24, 18, 24)
        ));
        detailsPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        JLabel basicInfoHeader = new JLabel("Basic Information");
        basicInfoHeader.setFont(new Font("Segoe UI", Font.BOLD, 17));
        basicInfoHeader.setBorder(BorderFactory.createEmptyBorder(0, 0, 6, 0));
        detailsPanel.add(basicInfoHeader);

        JLabel nameLabel = new JLabel("Name: " + employee.getFullName());
        nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        JLabel positionLabel = new JLabel("Position: " + employee.getPosition());
        positionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        JLabel rateLabel = new JLabel(String.format("Hourly Rate: %.2f", employee.getHourlyRate()));
        rateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));

        detailsPanel.add(nameLabel);
        detailsPanel.add(Box.createVerticalStrut(4));
        detailsPanel.add(positionLabel);
        detailsPanel.add(Box.createVerticalStrut(4));
        detailsPanel.add(rateLabel);
        detailsPanel.add(Box.createVerticalStrut(10));

        JLabel compHeader = new JLabel("Compensations:");
        compHeader.setFont(new Font("Segoe UI", Font.BOLD, 17));
        compHeader.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        JLabel riceLabel = new JLabel(String.format("  Rice Subsidy: %.2f", employee.getCompensation().getRiceSubsidy()));
        riceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        JLabel phoneLabel = new JLabel(String.format("  Phone Allowance: %.2f", employee.getCompensation().getPhoneAllowance()));
        phoneLabel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        JLabel clothingLabel = new JLabel(String.format("  Clothing Allowance: %.2f", employee.getCompensation().getClothingAllowance()));
        clothingLabel.setFont(new Font("Segoe UI", Font.PLAIN, 15));

        detailsPanel.add(compHeader);
        detailsPanel.add(Box.createVerticalStrut(2));
        detailsPanel.add(riceLabel);
        detailsPanel.add(Box.createVerticalStrut(2));
        detailsPanel.add(phoneLabel);
        detailsPanel.add(Box.createVerticalStrut(2));
        detailsPanel.add(clothingLabel);
        detailsPanel.add(Box.createVerticalStrut(2));

        dialog.add(detailsPanel, BorderLayout.CENTER);

        JButton viewSalaryBtn = new JButton("View Monthly Salary");
        JButton closeBtn = new JButton("Close");
        styleButtonSmall(viewSalaryBtn);
        viewSalaryBtn.setPreferredSize(new Dimension(180, 36));
        viewSalaryBtn.setMaximumSize(new Dimension(180, 36));
        styleButtonSmall(closeBtn);
        closeBtn.setPreferredSize(new Dimension(100, 36));
        closeBtn.setMaximumSize(new Dimension(100, 36));

        JPanel btnPanel = new JPanel();
        btnPanel.setLayout(new BoxLayout(btnPanel, BoxLayout.X_AXIS));
        btnPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        btnPanel.setBackground(dialog.getBackground());
        btnPanel.add(Box.createHorizontalGlue());
        btnPanel.add(viewSalaryBtn);
        btnPanel.add(Box.createRigidArea(new Dimension(16, 0)));
        btnPanel.add(closeBtn);
        btnPanel.add(Box.createHorizontalGlue());

        viewSalaryBtn.addActionListener(e -> {
            String input = StyledInputDialog(dialog, "Enter Month and Year", "Enter target month and year (yyyy-MM):");
            if (input == null) return;
            try {
                YearMonth ym = YearMonth.parse(input.trim());
                double gross = payrollService.calculateMonthlySalary(employee, ym);
                double net = payrollService.calculateNetSalary(employee, ym);
                String message = String.format("Payroll Summary for %s\nGross Salary: %.2f\nNet Salary: %.2f", ym, gross, net);
                StyledInfoDialog(dialog, "Payroll Summary", message);
            } catch (Exception ex) {
                StyledErrorDialog(dialog, "Error", "Invalid date format. Use yyyy-MM.");
            }
        });
        closeBtn.addActionListener(e -> dialog.dispose());
        dialog.add(btnPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void showAdminMenu() {// THIS IS DONE
        JDialog dialog = new JDialog(this, "Admin Menu", true);
        dialog.setSize(600, 450);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        String[] menuOptions = {
                "View All Employees",
                "View Employee Record",
                "Monthly Payroll Reports",
                "Weekly Payroll Reports",
                "Export Payroll Report to CSV",
                "Add New Employees",
                "Exit"

        };

      
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setBackground(Color.WHITE);
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

      
        menuPanel.add(Box.createVerticalGlue());

       
        for (String option : menuOptions) {
            JButton button = new JButton(option);
            styleButton(button);
            button.setPreferredSize(new Dimension(300, 40));
            button.setMaximumSize(new Dimension(300, 40));
            button.setAlignmentX(Component.CENTER_ALIGNMENT);

            menuPanel.add(Box.createVerticalStrut(10)); // space between buttons
            menuPanel.add(button);

            button.addActionListener(e -> {
                switch (option) {
                    case "View All Employees" -> showEmployeeList(dialog);
                    case "View Employee Record" -> {
                        Employee emp = promptEmployeeNumber(dialog);
                        if (emp != null) showDetailedEmployeeDialog(dialog, emp);
                    }
                    case "Monthly Payroll Reports" -> salaryCalculationMenu(dialog); // added from MS1 og view
                    case "Weekly Payroll Reports" -> showWeeklySalaryMenu(dialog); // added from MS1 og view
                    case "Export Payroll Report to CSV" -> exportPayrollReport(dialog);
                    case "Add New Employees" -> addNewEmp(dialog);
                    case "Exit" -> dialog.dispose();
        }
    });
}
        // sdd more 'glue' after buttons to keep everything vertically centered
        menuPanel.add(Box.createVerticalGlue());
        
        dialog.add(menuPanel, BorderLayout.CENTER);

        dialog.setVisible(true);
    }
    
    private void showWeeklySalaryMenu(Component parent) {
    JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(parent), "Weekly Payroll Reports", true);
    dialog.setSize(400, 300);
    dialog.setLocationRelativeTo(parent);
    dialog.setLayout(new BorderLayout());

    String[] options = {
        "Gross Salary for specific employee",
        "Net Salary for specific employee",
        "Close"
    };

    JPanel menuPanel = new JPanel();
    menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
    menuPanel.setBackground(Color.WHITE);
    menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

    menuPanel.add(Box.createVerticalGlue());

    for (String option : options) {
        JButton button = new JButton(option);
        styleButton(button);
        button.setPreferredSize(new Dimension(300, 40));
        button.setMaximumSize(new Dimension(300, 40));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        menuPanel.add(Box.createVerticalStrut(10));
        menuPanel.add(button);

        button.addActionListener(e -> {
            switch (option) {
                case "Gross Salary for specific employee" -> {
                    Employee emp = promptEmployeeNumber(dialog);
                    if (emp == null) return;
                    String input = StyledInputDialog(dialog, "Enter Reference Date", "Enter a reference date (yyyy-MM-dd):");
                    if (input == null) return;
                    try {
                        LocalDate date = LocalDate.parse(input.trim());
                        double gross = payrollService.calculateWeeklySalary(emp, date);
                        StyledInfoDialog(dialog, "Gross Weekly Salary",
                                String.format("Gross Salary for %s on week of %s: %.2f", emp.getFullName(), date, gross));
                    } catch (Exception ex) {
                        StyledErrorDialog(dialog, "Error", "Invalid date format. Use yyyy-MM-dd.");
                    }
                }
                case "Net Salary for specific employee" -> {
                    Employee emp = promptEmployeeNumber(dialog);
                    if (emp == null) return;
                    String input = StyledInputDialog(dialog, "Enter Reference Date", "Enter a reference date (yyyy-MM-dd):");
                    if (input == null) return;
                    try {
                        LocalDate date = LocalDate.parse(input.trim());
                        double net = payrollService.calculateNetWeeklySalary(emp, date);
                        StyledInfoDialog(dialog, "Net Weekly Salary",
                                String.format("Net Salary for %s on week of %s: %.2f", emp.getFullName(), date, net));
                    } catch (Exception ex) {
                        StyledErrorDialog(dialog, "Error", "Invalid date format. Use yyyy-MM-dd.");
                    }
                }
                case "Close" -> dialog.dispose();
            }
        });
    }

    menuPanel.add(Box.createVerticalGlue());
    dialog.add(menuPanel, BorderLayout.CENTER);
    dialog.setVisible(true);
}

    // WAIT
    private void showDetailedEmployeeDialog(Component parent, Employee emp) {
    JDialog detailDialog = new JDialog((Window) SwingUtilities.getWindowAncestor(parent), "Employee Details", Dialog.ModalityType.APPLICATION_MODAL);
    detailDialog.setSize(500, 700);
    detailDialog.setLocationRelativeTo(parent);
    detailDialog.setLayout(new BorderLayout());

    JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
    panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    panel.add(new JLabel("Full Name: " + emp.getFullName()));
    panel.add(new JLabel("Employee No.: " + emp.getEmployeeNumber()));
    panel.add(new JLabel("Birthday: " + emp.getBirthday()));
    panel.add(new JLabel("Position: " + emp.getPosition().getPosition()));
    panel.add(new JLabel("Position Type: " + emp.getPosition().getPosition()));
    panel.add(new JLabel("Status: " + emp.getStatus()));
    panel.add(new JLabel("Supervisor: " + (emp.getPosition().getSupervisor() != null
            ? emp.getPosition().getSupervisor().getFullName()
            : "None")));

    panel.add(new JLabel("Address: " + emp.getContact().getAddress()));
    panel.add(new JLabel("Phone: " + emp.getContact().getPhoneNumber()));

    panel.add(new JLabel("SSS #: " + emp.getGovernmentID().getSss()));
    panel.add(new JLabel("PhilHealth #: " + emp.getGovernmentID().getPhilhealth()));
    panel.add(new JLabel("TIN #: " + emp.getGovernmentID().getTin()));
    panel.add(new JLabel("Pag-IBIG #: " + emp.getGovernmentID().getPagibig()));

    panel.add(new JLabel("Basic Salary: ₱" + emp.getCompensation().getBasicSalary()));
    panel.add(new JLabel("Hourly Rate: ₱" + emp.getHourlyRate()));
    panel.add(new JLabel("Rice Subsidy: ₱" + emp.getCompensation().getRiceSubsidy()));
    panel.add(new JLabel("Phone Allowance: ₱" + emp.getCompensation().getPhoneAllowance()));
    panel.add(new JLabel("Clothing Allowance: ₱" + emp.getCompensation().getClothingAllowance()));
    panel.add(new JLabel("Semi-monthly Gross: ₱" + emp.getCompensation().getSemiGross()));

    JTextField monthField = new JTextField();
    panel.add(new JLabel("Enter Month (yyyy-MM):"));
    panel.add(monthField);

    JButton calcBtn = new JButton("Calculate Payroll");
    styleButtonSmall(calcBtn);

    calcBtn.addActionListener(e -> { // PAYROLL SUMMARY PROMPT
    try {
        YearMonth ym = YearMonth.parse(monthField.getText().trim(), DateTimeFormatter.ofPattern("yyyy-MM"));
        double gross = payrollService.calculateMonthlySalary(emp, ym);
        double net = payrollService.calculateNetSalary(emp, ym);

        List<String> summaryLines = List.of(
    "Payroll Summary for " + ym,
    "",
    "--- Employee Information ---",
    "Full Name: " + emp.getFullName(),
    "Employee No.: " + emp.getEmployeeNumber(),
    "Birthday: " + emp.getBirthday(),
    "Position: " + emp.getPosition().getPosition(),
    "Position Type: " + emp.getPosition().getPosition(),
    "Status: " + emp.getStatus(),
    "Supervisor: " + (emp.getPosition().getSupervisor() != null
        ? emp.getPosition().getSupervisor().getFullName()
        : "None"),
    "",
    "--- Contact ---",
    "Address: " + emp.getContact().getAddress(),
    "Phone: " + emp.getContact().getPhoneNumber(),
    "",
    "--- Government IDs ---",
    "SSS #: " + emp.getGovernmentID().getSss(),
    "PhilHealth #: " + emp.getGovernmentID().getPhilhealth(),
    "TIN #: " + emp.getGovernmentID().getTin(),
    "Pag-IBIG #: " + emp.getGovernmentID().getPagibig(),
    "",
    "--- Compensation ---",
    String.format("Basic Salary: ₱%.2f", emp.getCompensation().getBasicSalary()),
    String.format("Hourly Rate: ₱%.2f", emp.getHourlyRate()),
    String.format("Rice Subsidy: ₱%.2f", emp.getCompensation().getRiceSubsidy()),
    String.format("Phone Allowance: ₱%.2f", emp.getCompensation().getPhoneAllowance()),
    String.format("Clothing Allowance: ₱%.2f", emp.getCompensation().getClothingAllowance()),
    String.format("Semi-monthly Gross: ₱%.2f", emp.getCompensation().getSemiGross()),
    "",
    "--- Payroll for " + ym + " ---",
    String.format("Gross Salary: ₱%.2f", gross),
    String.format("Net Salary: ₱%.2f", net)
);

StyledPayrollPromptDialog(detailDialog, "Payroll Summary", summaryLines.toArray(new String[0]));

    } catch (Exception ex) {
        StyledErrorDialog(detailDialog, "Error", "Invalid date format. Use yyyy-MM.");
    }
});

    panel.add(calcBtn);
    detailDialog.add(new JScrollPane(panel), BorderLayout.CENTER);
    detailDialog.setVisible(true);
}


    private void showEmployeeList(Component parent) { // updated version of aly and red's fixed csv mishandling code
    JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(parent), "All Employees", true);
    dialog.setSize(950, 600);
    dialog.setLocationRelativeTo(parent);
    dialog.setLayout(new BorderLayout());

    String[] columns = {
        "Employee Number", "Last Name", "First Name", "Status",
        "SSS", "PhilHealth", "TIN", "Pag-IBIG"
    };

    DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
    JTable employeeTable = new JTable(tableModel);

    for (Employee emp : employees) {
        tableModel.addRow(new Object[]{
            emp.getEmployeeNumber(),
            emp.getLastName(),
            emp.getFirstName(),
            emp.getStatus(),
            emp.getGovernmentID().getSss(),
            emp.getGovernmentID().getPhilhealth(),
            emp.getGovernmentID().getTin(),
            emp.getGovernmentID().getPagibig()
        });
    }

    JScrollPane scrollPane = new JScrollPane(employeeTable);
    dialog.add(scrollPane, BorderLayout.CENTER);

    JButton viewBtn = new JButton("View Employee");
    JButton updateBtn = new JButton("Update");
    JButton deleteBtn = new JButton("Delete");

    styleButtonSmall(viewBtn);
    styleButtonSmall(updateBtn);
    styleButtonSmall(deleteBtn);

    updateBtn.setEnabled(false);
    deleteBtn.setEnabled(false);

    JPanel buttonPanel = new JPanel();
    buttonPanel.add(viewBtn);
    buttonPanel.add(updateBtn);
    buttonPanel.add(deleteBtn);

    dialog.add(buttonPanel, BorderLayout.SOUTH);

    employeeTable.getSelectionModel().addListSelectionListener(e -> {
        int row = employeeTable.getSelectedRow();
        updateBtn.setEnabled(row >= 0);
        deleteBtn.setEnabled(row >= 0);
    });

    viewBtn.addActionListener(e -> {
        int row = employeeTable.getSelectedRow();
        if (row == -1) {
            StyledErrorDialog(dialog, "Error", "Select an employee from the table.");
            return;
        }
        int empNum = (int) tableModel.getValueAt(row, 0);
        Employee emp = employeeService.findEmployeeByNumber(empNum);
        if (emp == null) {
            StyledErrorDialog(dialog, "Error", "Employee not found.");
            return;
        }
        showDetailedEmployeeDialog(dialog, emp);
    });
    
    // this is the update button, red's converted code
    updateBtn.addActionListener(e -> {
        int row = employeeTable.getSelectedRow();
        if (row < 0) return;

        int empNum = (int) tableModel.getValueAt(row, 0);
        Employee emp = employeeService.findEmployeeByNumber(empNum);
        if (emp == null) return;

        try {
            showUpdateDialog(dialog, emp);
        } catch (IOException ex) {
            Logger.getLogger(MainGUI.class.getName()).log(Level.SEVERE, null, ex);
        }

        // after dialog closes, it should refresh table row
        tableModel.setValueAt(emp.getLastName(), row, 1);
        tableModel.setValueAt(emp.getFirstName(), row, 2);
        tableModel.setValueAt(emp.getStatus(), row, 3);
        tableModel.setValueAt(emp.getGovernmentID().getSss(), row, 4);
        tableModel.setValueAt(emp.getGovernmentID().getPhilhealth(), row, 5);
        tableModel.setValueAt(emp.getGovernmentID().getTin(), row, 6);
        tableModel.setValueAt(emp.getGovernmentID().getPagibig(), row, 7);

        CSVWriter.writeEmployees(employees);
    });

    // this is the delete button code
    deleteBtn.addActionListener(e -> {
        int row = employeeTable.getSelectedRow();
        if (row >= 0) {
            int empNum = (int) tableModel.getValueAt(row, 0);
            Employee emp = employeeService.findEmployeeByNumber(empNum);
            if (emp != null) {
                int confirm = JOptionPane.showConfirmDialog(dialog,
                        "Are you sure you want to delete this employee?",
                        "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    employees.remove(emp);
                    tableModel.removeRow(row);
                    CSVWriter.writeEmployees(employees);
                    StyledInfoDialog(dialog, "Deleted", "Employee record deleted.");
                }
            }
        }
    });

    dialog.setVisible(true);
}
    
    //the output for the dialog when the update button is clicked on should be edited here
    private void showUpdateDialog(Window parent, Employee emp) throws IOException {
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MM/dd/yyyy");

        JTextField tfFirstName = new JTextField();
        JTextField tfLastName = new JTextField();
        JTextField tfBirthday = new JTextField();
        JTextField tfAddress = new JTextField();
        JTextField tfPhone = new JTextField();
        JTextField tfSSS = new JTextField();
        JTextField tfPhil = new JTextField();
        JTextField tfTIN = new JTextField();
        JTextField tfPagibig = new JTextField();
        JTextField tfStatus = new JTextField();
        JTextField tfPosition = new JTextField();
        JTextField tfSupervisor = new JTextField(emp.getPosition().getSupervisor() != null ? emp.getPosition().getSupervisor().getFullName() : "");
        JTextField tfBasic = new JTextField();
        JTextField tfRice = new JTextField();
        JTextField tfPhoneAllow = new JTextField();
        JTextField tfClothing = new JTextField();
        JTextField tfSemi = new JTextField();
        JTextField tfHourly = new JTextField();

        panel.add(new JLabel("First Name [" + emp.getFirstName() + "]:")); panel.add(tfFirstName);
        panel.add(new JLabel("Last Name [" + emp.getLastName() + "]:")); panel.add(tfLastName);
        panel.add(new JLabel("Birthday (MM/dd/yyyy) [" + emp.getBirthday().format(fmt) + "]:")); panel.add(tfBirthday);
        panel.add(new JLabel("Address [" + emp.getContact().getAddress() + "]:")); panel.add(tfAddress);
        panel.add(new JLabel("Phone [" + emp.getContact().getPhoneNumber() + "]:")); panel.add(tfPhone);
        panel.add(new JLabel("SSS [" + emp.getGovernmentID().getSss() + "]:")); panel.add(tfSSS);
        panel.add(new JLabel("PhilHealth [" + emp.getGovernmentID().getPhilhealth() + "]:")); panel.add(tfPhil);
        panel.add(new JLabel("TIN [" + emp.getGovernmentID().getTin() + "]:")); panel.add(tfTIN);
        panel.add(new JLabel("Pag-ibig [" + emp.getGovernmentID().getPagibig() + "]:")); panel.add(tfPagibig);
        panel.add(new JLabel("Status [" + emp.getStatus() + "]:")); panel.add(tfStatus);
        panel.add(new JLabel("Position [" + emp.getPosition().getPosition() + "]:")); panel.add(tfPosition);
        panel.add(new JLabel("Supervisor [" + tfSupervisor.getText() + "]:")); panel.add(tfSupervisor);
        panel.add(new JLabel("Basic Salary [" + emp.getCompensation().getBasicSalary() + "]:")); panel.add(tfBasic);
        panel.add(new JLabel("Rice Subsidy [" + emp.getCompensation().getRiceSubsidy() + "]:")); panel.add(tfRice);
        panel.add(new JLabel("Phone Allowance [" + emp.getCompensation().getPhoneAllowance() + "]:")); panel.add(tfPhoneAllow);
        panel.add(new JLabel("Clothing Allowance [" + emp.getCompensation().getClothingAllowance() + "]:")); panel.add(tfClothing);
        panel.add(new JLabel("Semi-Monthly [" + emp.getCompensation().getSemiGross() + "]:")); panel.add(tfSemi);
        panel.add(new JLabel("Hourly Rate [" + emp.getHourlyRate() + "]:")); panel.add(tfHourly);

        int result = JOptionPane.showConfirmDialog(parent, panel, "Update Employee", JOptionPane.OK_CANCEL_OPTION);
        if (result != JOptionPane.OK_OPTION) return;

        // update only non-empty fields like CLI update logic
        if (!tfFirstName.getText().trim().isEmpty()) {
            emp.setFirstName(tfFirstName.getText().trim());
        }
        if (!tfLastName.getText().trim().isEmpty()) {
            emp.setLastName(tfLastName.getText().trim());
        }
        if (!tfBirthday.getText().trim().isEmpty()) {
            try {
                emp.setBirthday(LocalDate.parse(tfBirthday.getText().trim(), fmt));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(parent, "Invalid birthday format. Birthday not updated.", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        }
        if (!tfAddress.getText().trim().isEmpty()) {
            emp.getContact().setAddress(tfAddress.getText().trim());
        }
        if (!tfPhone.getText().trim().isEmpty()) {
            emp.getContact().setPhoneNumber(tfPhone.getText().trim());
        }
        GovernmentID govID = emp.getGovernmentID();
        if (!tfSSS.getText().trim().isEmpty()) govID.setSss(tfSSS.getText().trim());
        if (!tfPhil.getText().trim().isEmpty()) govID.setPhilhealth(tfPhil.getText().trim());
        if (!tfTIN.getText().trim().isEmpty()) govID.setTin(tfTIN.getText().trim());
        if (!tfPagibig.getText().trim().isEmpty()) govID.setPagibig(tfPagibig.getText().trim());

        if (!tfStatus.getText().trim().isEmpty()) {
            emp.setStatus(tfStatus.getText().trim());
        }
        if (!tfPosition.getText().trim().isEmpty()) {
            emp.getPosition().setPosition(tfPosition.getText().trim());
        }

        if (!tfSupervisor.getText().trim().isEmpty()) {
            Employee supervisor = employees.stream()
                .filter(e -> e.getFullName().equalsIgnoreCase(tfSupervisor.getText().trim()))
                .findFirst().orElse(null);
            emp.getPosition().setSupervisor(supervisor);
        }

        Compensation comp = emp.getCompensation();

        try {
            comp.setBasicSalary(parseDoubleOrKeep(tfBasic.getText(), comp.getBasicSalary()));
            comp.setRiceSubsidy(parseDoubleOrKeep(tfRice.getText(), comp.getRiceSubsidy()));
            comp.setPhoneAllowance(parseDoubleOrKeep(tfPhoneAllow.getText(), comp.getPhoneAllowance()));
            comp.setClothingAllowance(parseDoubleOrKeep(tfClothing.getText(), comp.getClothingAllowance()));
            comp.setSemiGross(parseDoubleOrKeep(tfSemi.getText(), comp.getSemiGross()));
            if (!tfHourly.getText().trim().isEmpty()) {
                emp.setHourlyRate(Double.parseDouble(tfHourly.getText().trim()));
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(parent, "Invalid number entered. Some fields were not updated.", "Warning", JOptionPane.WARNING_MESSAGE);
        }

        // After all updates, write back to CSV
        CSVWriter.updateEmployeeInCSV(emp);

        JOptionPane.showMessageDialog(parent, "Employee record updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    // this is a helper method for parsing doubles or returning old value if empty
    private double parseDoubleOrKeep(String input, double oldValue) throws NumberFormatException {
        if (input == null || input.trim().isEmpty()) {
            return oldValue;
        }
        return Double.parseDouble(input.trim());
    }


        private void salaryCalculationMenu(Component parent) { // THIS IS DONE
            JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(parent), "Salary Calculation", true);
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(parent);
        dialog.setLayout(new BorderLayout());

        String[] options = {
            "Gross Salary for ALL employees",
            "Net Salary for ALL employees",
            "Gross Salary for specific employee",
            "Net Salary for specific employee",
            "Close"
        };

        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setBackground(Color.WHITE);
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        menuPanel.add(Box.createVerticalGlue());

        for (String option : options) {
            JButton button = new JButton(option);
            styleButton(button);
            button.setPreferredSize(new Dimension(300, 40));
            button.setMaximumSize(new Dimension(300, 40));
            button.setAlignmentX(Component.CENTER_ALIGNMENT);

            menuPanel.add(Box.createVerticalStrut(10));
            menuPanel.add(button);

            button.addActionListener(e -> {
                switch (option) {
                    case "Gross Salary for ALL employees" -> {
                        YearMonth ym = promptYearMonth(dialog);
                        if (ym == null) return;

                        String[] columnNames = {"Employee Number", "Full Name", "Gross Salary"};
                        Object[][] data = new Object[employees.size()][3];
                        int i = 0;
                        for (Employee emp : employees) {
                            double gross = payrollService.calculateMonthlySalary(emp, ym);
                            data[i][0] = emp.getEmployeeNumber();
                            data[i][1] = emp.getFullName();
                            data[i][2] = String.format("%.2f", gross);
                            i++;
                        }

                        JTable table = new JTable(data, columnNames);
                        JScrollPane scrollPane = new JScrollPane(table);
                        table.setFillsViewportHeight(true);

                        JDialog tableDialog = new JDialog(dialog, "Gross Salaries for " + ym, true);
                        tableDialog.setSize(600, 400);
                        tableDialog.setLocationRelativeTo(dialog);
                        tableDialog.add(scrollPane);
                        tableDialog.setVisible(true);
                    }

                    case "Net Salary for ALL employees" -> {
                        YearMonth ym = promptYearMonth(dialog);
                        if (ym == null) return;

                        String[] columnNames = {"Employee Number", "Full Name", "Net Salary"};
                        Object[][] data = new Object[employees.size()][3];
                        int i = 0;
                        for (Employee emp : employees) {
                            double net = payrollService.calculateNetSalary(emp, ym);
                            data[i][0] = emp.getEmployeeNumber();
                            data[i][1] = emp.getFullName();
                            data[i][2] = String.format("%.2f", net);
                            i++;
                        }

                        JTable table = new JTable(data, columnNames);
                        JScrollPane scrollPane = new JScrollPane(table);
                        table.setFillsViewportHeight(true);

                        JDialog tableDialog = new JDialog(dialog, "Net Salaries for " + ym, true);
                        tableDialog.setSize(600, 400);
                        tableDialog.setLocationRelativeTo(dialog);
                        tableDialog.add(scrollPane);
                        tableDialog.setVisible(true);
                    }

                    case "Gross Salary for specific employee" -> {
                        Employee emp = promptEmployeeNumber(dialog);
                        if (emp == null) return;
                        YearMonth ym = promptYearMonth(dialog);
                        if (ym == null) return;
                        double gross = payrollService.calculateMonthlySalary(emp, ym);
                        StyledInfoDialog(dialog, "Gross Salary", String.format("Gross Salary for %s in %s: %.2f", emp.getFullName(), ym, gross));
                    }

                    case "Net Salary for specific employee" -> {
                        Employee emp = promptEmployeeNumber(dialog);
                        if (emp == null) return;
                        YearMonth ym = promptYearMonth(dialog);
                        if (ym == null) return;
                        double net = payrollService.calculateNetSalary(emp, ym);
                        StyledInfoDialog(dialog, "Net Salary", String.format("Net Salary for %s in %s: %.2f", emp.getFullName(), ym, net));
                    }

                    case "Close" -> dialog.dispose();
                }
            });
        }

        menuPanel.add(Box.createVerticalGlue());
        dialog.add(menuPanel, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    private void exportPayrollReport(Component parent) { // Find way to edit view or design
        YearMonth ym = promptYearMonth(parent);
        if (ym == null) return;

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select CSV File to Save Payroll Report");
        fileChooser.setSelectedFile(new File("payroll_report_" + ym + ".csv"));

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try {
                payrollService.exportPayrollReportToCSV(employees, ym, fileToSave.getAbsolutePath());
                JOptionPane.showMessageDialog(this, "Payroll report exported to:\n" + fileToSave.getAbsolutePath());
            } catch (Exception e) {
                StyledErrorDialog(this, "Error", "Error exporting CSV: " + e.getMessage());
            }
        }
    }
    
    private void addNewEmp(Component parent) { // code for adding new employee data christine's project
    try {
        int empNum = Integer.parseInt(StyledInputDialog(this, "Add Employee", "Enter Employee Number:"));
        String firstName = StyledInputDialog(this, "Add Employee", "Enter First Name:");
        String lastName = StyledInputDialog(this, "Add Employee", "Enter Last Name:");

        String birthdayStr = StyledInputDialog(this, "Add Employee", "Enter Birthday (MM/dd/yyyy):");
        LocalDate birthday = LocalDate.parse(birthdayStr, DateTimeFormatter.ofPattern("MM/dd/yyyy"));

        String address = StyledInputDialog(this, "Add Employee", "Enter Address:");
        String phone = StyledInputDialog(this, "Add Employee", "Enter Phone Number:");

        String sss = StyledInputDialog(this, "Add Employee", "Enter SSS #: ");
        String philhealth = StyledInputDialog(this, "Add Employee", "Enter PhilHealth #: ");
        String tin = StyledInputDialog(this, "Add Employee", "Enter TIN #: ");
        String pagibig = StyledInputDialog(this, "Add Employee", "Enter Pag-ibig #: ");

        String status = StyledInputDialog(this, "Add Employee", "Enter Status (Regular, Contractual, etc.): ");
        String posTitle = StyledInputDialog(this, "Add Employee", "Enter Position Title: ");

        String supervisorName = StyledInputDialog(this, "Add Employee", "Immediate Supervisor (full name or leave blank):");
        Employee supervisor = employees.stream()
                .filter(e -> e.getFullName().equalsIgnoreCase(supervisorName))
                .findFirst()
                .orElse(null);

        double basic = Double.parseDouble(StyledInputDialog(this, "Add Employee", "Enter Basic Salary: "));
        double rice = Double.parseDouble(StyledInputDialog(this, "Add Employee", "Enter Rice Subsidy: "));
        double phoneAllow = Double.parseDouble(StyledInputDialog(this, "Add Employee", "Enter Phone Allowance: "));
        double clothing = Double.parseDouble(StyledInputDialog(this, "Add Employee", "Enter Clothing Allowance: "));
        double semiGross = Double.parseDouble(StyledInputDialog(this, "Add Employee", "Enter Gross Semi-Monthly Rate: "));
        double hourly = Double.parseDouble(StyledInputDialog(this, "Add Employee", "Enter Hourly Rate: "));

        Employee emp = new Employee(
                empNum,
                firstName,
                lastName,
                birthday,
                new ContactInfo(address, phone),
                new GovernmentID(sss, philhealth, tin, pagibig),
                new Position(posTitle, supervisor),
                new Compensation(basic, rice, phoneAllow, clothing, semiGross, hourly),
                status,
                "" // department or additional data if needed
        );

        // Add to list and write to specific CSV file
        CSVWriter.appendEmployeeToCSV(emp); 
        employees.add(emp);                   


        StyledInfoDialog(this, "Success", "New employee added successfully!");

    } catch (Exception e) {
        StyledErrorDialog(this, "Error", "Failed to add employee: " + e.getMessage());
    }
}

    private YearMonth promptYearMonth(Component parent) {
    String input = StyledInputDialog(parent, "Enter Month and Year", "Enter month and year (yyyy-MM):");
    if (input == null) return null;
    try {
        return YearMonth.parse(input.trim());
    } catch (Exception e) {
        StyledErrorDialog(parent, "Error", "Invalid format. Use yyyy-MM.");
        return null;
    }
}
    private Employee promptEmployeeNumber(Component parent) {
        String input = StyledInputDialog(parent, "Enter Employee Number", "Enter employee number:");
        if (input == null) return null; // User cancelled

        try {
            int empNum = Integer.parseInt(input.trim());
            Employee emp = employeeService.findEmployeeByNumber(empNum);
            if (emp == null) {
                StyledErrorDialog(parent, "Error", "Employee not found.");
            }
            return emp;
        } catch (NumberFormatException e) {
            StyledErrorDialog(parent, "Error", "Invalid employee number.");
            return null;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainGUI().setVisible(true));
    }
    
    private String StyledInputDialog(Component parent, String title, String message) {
        JDialog inputDialog = new JDialog((Window) SwingUtilities.getWindowAncestor(parent), title, ModalityType.APPLICATION_MODAL);
        inputDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        inputDialog.setSize(380, 170);
        inputDialog.setResizable(false);
        inputDialog.setLocationRelativeTo(parent);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
        mainPanel.setBackground(new Color(250, 252, 255));

        JLabel promptLabel = new JLabel(message);
        promptLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        promptLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        promptLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));

        JTextField inputField = new JTextField();
        inputField.setPreferredSize(new Dimension(325, 28));
        inputField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        inputField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        inputField.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(14, 0, 0, 0));

        JButton okButton = new JButton("OK");
        JButton cancelButton = new JButton("Cancel");
        styleButtonSmall(okButton);
        styleButtonSmall(cancelButton);
        okButton.setPreferredSize(new Dimension(100, 36));
        cancelButton.setPreferredSize(new Dimension(100, 36));
        okButton.setMaximumSize(new Dimension(100, 36));
        cancelButton.setMaximumSize(new Dimension(100, 36));

        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(okButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(16, 0)));
        buttonPanel.add(cancelButton);
        buttonPanel.add(Box.createHorizontalGlue());

        final String[] result = new String[1];
        result[0] = null;

        okButton.addActionListener(e -> {
            result[0] = inputField.getText().trim();
            inputDialog.dispose();
        });
        cancelButton.addActionListener(e -> {
            result[0] = null;
            inputDialog.dispose();
        });

        mainPanel.add(promptLabel);
        mainPanel.add(inputField);
        mainPanel.add(buttonPanel);

        inputDialog.setContentPane(mainPanel);
        inputDialog.getRootPane().setDefaultButton(okButton);
        inputDialog.setVisible(true);

        return result[0];
    }
    
    private void StyledErrorDialog(Component parent, String title, String message) {
        JDialog errorDialog = new JDialog((Window) SwingUtilities.getWindowAncestor(parent), title, Dialog.ModalityType.APPLICATION_MODAL);
        errorDialog.setLayout(new BorderLayout(10, 10));
        errorDialog.setSize(340, 150);
        errorDialog.setLocationRelativeTo(parent);
        errorDialog.getContentPane().setBackground(new Color(245, 248, 250));

        // Icon and message panel
        JPanel contentPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 18));
        contentPanel.setOpaque(false);
        JLabel iconLabel = new JLabel(UIManager.getIcon("OptionPane.errorIcon"));
        JLabel messageLabel = new JLabel(message);
        messageLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        contentPanel.add(iconLabel);
        contentPanel.add(messageLabel);

        // OK button
        JButton okButton = new JButton("OK");
        styleButtonSmall(okButton);
        okButton.setPreferredSize(new Dimension(80, 32));
        okButton.setMaximumSize(new Dimension(80, 32));
        okButton.addActionListener(e -> errorDialog.dispose());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        buttonPanel.add(okButton);

        errorDialog.add(contentPanel, BorderLayout.CENTER);
        errorDialog.add(buttonPanel, BorderLayout.SOUTH);
        errorDialog.setVisible(true);
    }
    
    private void StyledPayrollPromptDialog(Component parent, String title, String[] lines) { // NEW HELPER FOR PAYROLL SUMMARY PROMPT
        JDialog payrollDialog = new JDialog((Window) SwingUtilities.getWindowAncestor(parent), title, Dialog.ModalityType.APPLICATION_MODAL);
        payrollDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        payrollDialog.setSize(500, 600);
        payrollDialog.setResizable(false);
        payrollDialog.setLocationRelativeTo(parent);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
        contentPanel.setBackground(new Color(245, 248, 250));

        Font boldFont = new Font("Segoe UI", Font.BOLD, 14);
        Font plainFont = new Font("Segoe UI", Font.PLAIN, 14);

        for (String line : lines) {
            if (line.trim().isEmpty()) {
                contentPanel.add(Box.createVerticalStrut(10));
                continue;
            }

            JLabel label;
            if (line.startsWith("---")) {
                label = new JLabel(line.replace("---", "").trim());
                label.setFont(boldFont);
                label.setBorder(BorderFactory.createEmptyBorder(10, 0, 4, 0));
            } else {
                label = new JLabel(line);
                label.setFont(plainFont);
            }
            contentPanel.add(label);
        }

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(new Color(245, 248, 250));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(14, 18, 12, 18));

        JButton okButton = new JButton("OK");
        styleButtonSmall(okButton);
        okButton.setPreferredSize(new Dimension(100, 36));
        okButton.setMaximumSize(new Dimension(100, 36));
        okButton.addActionListener(e -> payrollDialog.dispose());

        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(okButton);
        buttonPanel.add(Box.createHorizontalGlue());

        payrollDialog.setLayout(new BorderLayout());
        payrollDialog.add(scrollPane, BorderLayout.CENTER);
        payrollDialog.add(buttonPanel, BorderLayout.SOUTH);
        payrollDialog.getRootPane().setDefaultButton(okButton);
        payrollDialog.setVisible(true);
}

    private void StyledInfoDialog(Component parent, String title, String message) {
    JDialog dialog = new JDialog((Window) SwingUtilities.getWindowAncestor(parent), title, Dialog.ModalityType.APPLICATION_MODAL);
    dialog.setLayout(new BorderLayout(10, 10));
    dialog.setSize(350, 180);
    dialog.setLocationRelativeTo(parent);

    JTextArea messageArea = new JTextArea(message);
    messageArea.setEditable(false);
    messageArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    messageArea.setWrapStyleWord(true);
    messageArea.setLineWrap(true);
    messageArea.setBackground(dialog.getBackground());
    messageArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JButton okButton = new JButton("OK");
    styleButtonSmall(okButton);
    okButton.setPreferredSize(new Dimension(60, 30));

    okButton.addActionListener(e -> dialog.dispose());

    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    buttonPanel.add(okButton);

    dialog.add(new JScrollPane(messageArea), BorderLayout.CENTER);
    dialog.add(buttonPanel, BorderLayout.SOUTH);

    dialog.setVisible(true);
}
}