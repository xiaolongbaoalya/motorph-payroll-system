package com.compprog1282025.auth;

public enum UserRole {
    EMPLOYEE,
    ADMIN
}