package com.compprog1282025.util;

import com.compprog1282025.model.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class CSVReader {

    public static List<Employee> readEmployees(String filePath) {
    List<Employee> employees = new ArrayList<>();
    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    try (
        InputStream is = CSVReader.class.getClassLoader().getResourceAsStream(filePath);
        BufferedReader br = is != null
            ? new BufferedReader(new InputStreamReader(is))
            : new BufferedReader(new FileReader(filePath))
    ) {
        String line;
        boolean firstLine = true;

        while ((line = br.readLine()) != null) {
            if (firstLine) {
                firstLine = false;
                continue;
            }

            // Split while handling quoted commas
            String[] fields = parseCSVLine(line);
            int index = 0;

            int employeeNumber = Integer.parseInt(fields[index++].trim());
            String lastName = fields[index++].trim();
            String firstName = fields[index++].trim();
            LocalDate birthday = LocalDate.parse(fields[index++].trim(), dateFormatter);

            String address = fields[index++].trim();
            String phoneNumber = fields[index++].trim();
            ContactInfo contact = new ContactInfo(address, phoneNumber);

            String sss = fields[index++].trim();
            String philhealth = fields[index++].trim();
            String tin = fields[index++].trim();
            String pagibig = fields[index++].trim();
            GovernmentID governmentID = new GovernmentID(sss, philhealth, tin, pagibig);

            String status = fields[index++].trim();
            String positionTitle = fields[index++].trim();
            String supervisorName = fields[index++].trim(); // Can handle later
            Position position = new Position(positionTitle, null);

            double basicSalary = parseDoubleSafe(fields[index++]);
            double riceSubsidy = parseDoubleSafe(fields[index++]);
            double phoneAllowance = parseDoubleSafe(fields[index++]);
            double clothingAllowance = parseDoubleSafe(fields[index++]);
            double semiGross = parseDoubleSafe(fields[index++]); // Optional
            double hourlyRate = parseDoubleSafe(fields[index++]);

            Compensation compensation = new Compensation(basicSalary, riceSubsidy, phoneAllowance, clothingAllowance, semiGross, hourlyRate);

            String password = "default";

            Employee employee = new Employee(
                employeeNumber,
                firstName,
                lastName,
                birthday,
                contact,
                governmentID,
                position,
                compensation,
                status,
                password
            );

            employees.add(employee);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return employees;
    }

    private static double parseDoubleSafe(String raw) {
        if (raw == null || raw.trim().isEmpty() || raw.trim().equalsIgnoreCase("N/A")) return 0.0;
        return Double.parseDouble(raw.replace(",", "").trim());
    }

    private static String[] parseCSVLine(String line) {
    List<String> tokens = new ArrayList<>();
    StringBuilder current = new StringBuilder();
    boolean inQuotes = false;

    for (int i = 0; i < line.length(); i++) {
        char ch = line.charAt(i);

        if (ch == '"') {
            inQuotes = !inQuotes;
        } else if (ch == ',' && !inQuotes) {
            tokens.add(current.toString());
            current.setLength(0);
        } else {
            current.append(ch);
        }
    }

    tokens.add(current.toString()); // add the last token
    return tokens.toArray(new String[0]);
    }

    private static final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("H:mm");

    public static List<Attendance> readAttendance(String filePath, Map<Integer, Employee> employeeMap) {
    List<Attendance> attendanceRecords = new ArrayList<>();
    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("H:mm");

    try (
        InputStream is = CSVReader.class.getClassLoader().getResourceAsStream(filePath);
        BufferedReader br = is != null
            ? new BufferedReader(new InputStreamReader(is))
            : new BufferedReader(new FileReader(filePath))
    ) {
        String line;
        boolean firstLine = true;

        while ((line = br.readLine()) != null) {
            if (firstLine) {
                firstLine = false;
                continue;
            }

            String[] fields = line.split(",", -1); // Keep empty fields

            int index = 0;
            int employeeNumber = Integer.parseInt(fields[index++].trim());
            String lastName = fields[index++].trim();   // Optional
            String firstName = fields[index++].trim();  // Optional
            LocalDate date = LocalDate.parse(fields[index++].trim(), dateFormatter);
            LocalTime timeIn = LocalTime.parse(fields[index++].trim(), timeFormatter);
            LocalTime timeOut = LocalTime.parse(fields[index++].trim(), timeFormatter);

            Employee employee = employeeMap.get(employeeNumber);
            if (employee != null) {
                Attendance record = new Attendance(employee, date, timeIn, timeOut);
                attendanceRecords.add(record);
            } else {
                System.err.println("Unknown employee number in attendance: " + employeeNumber);
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return attendanceRecords;
    }
}
