package com.compprog1282025.service;

import com.compprog1282025.Main;
import com.compprog1282025.model.Employee;
import com.compprog1282025.util.DeductionsUtil;
import com.compprog1282025.util.CSVReader;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.YearMonth;
import java.util.List;

public class PayrollService {

    private final AttendanceService attendanceService;

    public PayrollService(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    public double calculateMonthlySalary(Employee employee, YearMonth month) {
        double hoursWorked = attendanceService.calculateMonthlyHours(employee, month);
        double baseSalary = hoursWorked * employee.getHourlyRate();

        // Add fixed allowances
        double allowances = employee.getCompensation().getRiceSubsidy()
                           + employee.getCompensation().getPhoneAllowance()
                           + employee.getCompensation().getClothingAllowance();

        return baseSalary + allowances;
    }

    public double calculateNetSalary(Employee employee, YearMonth month) {
        double grossSalary = calculateMonthlySalary(employee, month);

        // Deductions
        double philHealth = DeductionsUtil.calculatePhilhealth(grossSalary);
        double pagIbig = DeductionsUtil.calculatePagIbig(grossSalary);
        double sss = DeductionsUtil.calculateSSS(grossSalary);
        double taxableIncome = grossSalary - (philHealth + pagIbig + sss);
        double withholdingTax = DeductionsUtil.calculateWithholdingTax(taxableIncome);

        double totalDeductions = philHealth + pagIbig + sss + withholdingTax;

        return grossSalary - totalDeductions;
    }

    public void printPayrollReport(List<Employee> employees, YearMonth month) {
        System.out.println("\nPayroll Report for " + month);
        for (Employee e : employees) {
            double gross = calculateMonthlySalary(e, month);
            double net = calculateNetSalary(e, month);
            System.out.printf("[%d] %s\n", e.getEmployeeNumber(), e.getFullName());
            System.out.printf("  Gross Salary: %.2f\n", gross);
            System.out.printf("  Net Salary:   %.2f\n", net);
            System.out.println();
        }
    }

    public void exportPayrollReportToCSV(List<Employee> employees, YearMonth month, String filePath) {
    try {
        Path projectRoot = Paths.get(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI())
                                .getParent().getParent();

        File file = new File(filePath);

        if (!file.isAbsolute()) {
            file = projectRoot.resolve(filePath).toFile();
        }

        File parentDir = file.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs();
        }

        try (PrintWriter writer = new PrintWriter(file)) {
            writer.println("Employee Number,Full Name,Gross Salary,Net Salary");

            for (Employee emp : employees) {
                double gross = calculateMonthlySalary(emp, month);
                double net = calculateNetSalary(emp, month);
                writer.printf("%d,%s,%.2f,%.2f%n",
                        emp.getEmployeeNumber(),
                        emp.getFullName(),
                        gross,
                        net);
            }

            System.out.println("Payroll report exported successfully to: " + file.getAbsolutePath());
        }
    } catch (Exception e) {
        System.out.println("Failed to export payroll report: " + e.getMessage());
        }
    }

}
