package com.compprog1282025.service;

import com.compprog1282025.model.Employee;
import com.compprog1282025.model.Attendance;
import com.compprog1282025.util.CSVReader;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DataLoaderService {

    private List<Employee> employees;
    private List<Attendance> attendanceRecords;

    public void loadAllData() {
        // Load employees from CSV
        employees = CSVReader.readEmployees("employees.csv");

        // Create map from employee number to Employee object
        Map<Integer, Employee> employeeMap = employees.stream()
            .collect(Collectors.toMap(Employee::getEmployeeNumber, e -> e));

        // Load attendance using that map
        attendanceRecords = CSVReader.readAttendance("attendance.csv", employeeMap);
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public List<Attendance> getAttendanceRecords() {
        return attendanceRecords;
    }
}
