package com.compprog1282025.controller;

import com.compprog1282025.model.Employee;

import java.util.List;

public class EmployeeService {
}
