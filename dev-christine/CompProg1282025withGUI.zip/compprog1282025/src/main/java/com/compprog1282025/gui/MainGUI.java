package com.compprog1282025.gui;

import com.compprog1282025.auth.UserRole;
import com.compprog1282025.model.Employee;
import com.compprog1282025.model.Attendance;
import com.compprog1282025.service.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.time.YearMonth;
import java.util.List;

public class MainGUI extends JFrame {

    private final EmployeeService employeeService;
    private final AttendanceService attendanceService;
    private final PayrollService payrollService;
    private final List<Employee> employees;

    public MainGUI() {
        // Load data
        DataLoaderService loader = new DataLoaderService();
        loader.loadAllData();

        employees = loader.getEmployees();
        List<Attendance> attendanceRecords = loader.getAttendanceRecords();

        attendanceService = new AttendanceService(attendanceRecords);
        payrollService = new PayrollService(attendanceService);
        employeeService = new EmployeeService(employees);

        initUI();
    }

    private void initUI() {
        setTitle("Payroll System");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel label = new JLabel("Login as:");
        label.setFont(new Font("Segoe UI", Font.BOLD, 18));

        JButton employeeBtn = new JButton("Employee");
        JButton adminBtn = new JButton("Admin");

        employeeBtn.setPreferredSize(new Dimension(120, 35));
        adminBtn.setPreferredSize(new Dimension(120, 35));

        employeeBtn.addActionListener(e -> employeeLogin());
        adminBtn.addActionListener(e -> showAdminMenu());

        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(label, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        panel.add(employeeBtn, gbc);

        gbc.gridx = 1;
        panel.add(adminBtn, gbc);

        add(panel);
    }

    private void employeeLogin() {
        String input = JOptionPane.showInputDialog(this, "Enter your Employee Number:");
        if (input == null) return; // Cancel pressed
        try {
            int empNum = Integer.parseInt(input.trim());
            Employee employee = employeeService.findEmployeeByNumber(empNum);
            if (employee != null) {
                showEmployeeDashboard(employee);
            } else {
                JOptionPane.showMessageDialog(this, "Employee not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid employee number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showEmployeeDashboard(Employee employee) {
        JDialog dialog = new JDialog(this, "Employee Dashboard - " + employee.getFullName(), true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(10, 10));

        JTextArea infoArea = new JTextArea();
        infoArea.setEditable(false);
        infoArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        infoArea.setText(String.format(
                "Name: %s\nPosition: %s\nHourly Rate: %.2f\n\nCompensations:\n  Rice Subsidy: %.2f\n  Phone Allowance: %.2f\n  Clothing Allowance: %.2f",
                employee.getFullName(), employee.getPosition(), employee.getHourlyRate(),
                employee.getCompensation().getRiceSubsidy(),
                employee.getCompensation().getPhoneAllowance(),
                employee.getCompensation().getClothingAllowance()));

        dialog.add(new JScrollPane(infoArea), BorderLayout.CENTER);

        JButton viewSalaryBtn = new JButton("View Monthly Salary");
        JButton closeBtn = new JButton("Close");

        JPanel btnPanel = new JPanel();
        btnPanel.add(viewSalaryBtn);
        btnPanel.add(closeBtn);

        viewSalaryBtn.addActionListener(e -> {
            String input = JOptionPane.showInputDialog(dialog, "Enter target month and year (yyyy-MM):");
            if (input == null) return;
            try {
                YearMonth ym = YearMonth.parse(input.trim());
                double gross = payrollService.calculateMonthlySalary(employee, ym);
                double net = payrollService.calculateNetSalary(employee, ym);
                JOptionPane.showMessageDialog(dialog,
                        String.format("Payroll Summary for %s\nGross Salary: %.2f\nNet Salary: %.2f", ym, gross, net));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid date format. Use yyyy-MM.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        closeBtn.addActionListener(e -> dialog.dispose());

        dialog.add(btnPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void showAdminMenu() {
        JDialog dialog = new JDialog(this, "Admin Menu", true);
        dialog.setSize(600, 450);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        String[] menuOptions = {
                "View All Employees",
                "Salary Calculation",
                "Export Payroll Report to CSV",
                "Exit"
        };

        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (String option : menuOptions) {
            listModel.addElement(option);
        }

        JList<String> menuList = new JList<>(listModel);
        menuList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        menuList.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        JScrollPane scrollPane = new JScrollPane(menuList);

        JButton selectBtn = new JButton("Select");
        JButton closeBtn = new JButton("Close");

        JPanel btnPanel = new JPanel();
        btnPanel.add(selectBtn);
        btnPanel.add(closeBtn);

        dialog.add(scrollPane, BorderLayout.CENTER);
        dialog.add(btnPanel, BorderLayout.SOUTH);

        selectBtn.addActionListener(e -> {
            int selected = menuList.getSelectedIndex();
            switch (selected) {
                case 0 -> showEmployeeList(dialog);
                case 1 -> salaryCalculationMenu(dialog);
                case 2 -> exportPayrollReport(dialog);
                case 3 -> dialog.dispose();
                default -> JOptionPane.showMessageDialog(dialog, "Please select an option.");
            }
        });

        closeBtn.addActionListener(e -> dialog.dispose());

        dialog.setVisible(true);
    }

    private void showEmployeeList(Component parent) {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(parent), "All Employees", true);
        dialog.setSize(700, 400);
        dialog.setLocationRelativeTo(parent);

        String[] columns = {"Employee Number", "Full Name", "Position", "Hourly Rate"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        for (Employee e : employees) {
            model.addRow(new Object[]{
                    e.getEmployeeNumber(),
                    e.getFullName(),
                    e.getPosition(),
                    e.getHourlyRate()
            });
        }

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        dialog.add(scrollPane);
        dialog.setVisible(true);
    }

    private void salaryCalculationMenu(Component parent) {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(parent), "Salary Calculation", true);
        dialog.setSize(350, 200);
        dialog.setLocationRelativeTo(parent);
        dialog.setLayout(new GridLayout(6, 1, 10, 10));

        JButton grossAllBtn = new JButton("Gross Salary for ALL employees");
        JButton netAllBtn = new JButton("Net Salary for ALL employees");
        JButton grossEmpBtn = new JButton("Gross Salary for specific employee");
        JButton netEmpBtn = new JButton("Net Salary for specific employee");
        JButton closeBtn = new JButton("Close");

        dialog.add(grossAllBtn);
        dialog.add(netAllBtn);
        dialog.add(grossEmpBtn);
        dialog.add(netEmpBtn);
        dialog.add(closeBtn);

        grossAllBtn.addActionListener(e -> {
            YearMonth ym = promptYearMonth(dialog);
            if (ym == null) return;
            StringBuilder sb = new StringBuilder("Gross Salaries for " + ym + ":\n\n");
            for (Employee emp : employees) {
                double gross = payrollService.calculateMonthlySalary(emp, ym);
                sb.append(String.format("Employee %d (%s): %.2f%n", emp.getEmployeeNumber(), emp.getFullName(), gross));
            }
            showLongText(dialog, "Gross Salaries", sb.toString());
        });

        netAllBtn.addActionListener(e -> {
            YearMonth ym = promptYearMonth(dialog);
            if (ym == null) return;
            StringBuilder sb = new StringBuilder("Net Salaries for " + ym + ":\n\n");
            for (Employee emp : employees) {
                double net = payrollService.calculateNetSalary(emp, ym);
                sb.append(String.format("Employee %d (%s): %.2f%n", emp.getEmployeeNumber(), emp.getFullName(), net));
            }
            showLongText(dialog, "Net Salaries", sb.toString());
        });

        grossEmpBtn.addActionListener(e -> {
            Employee emp = promptEmployeeNumber(dialog);
            if (emp == null) return;
            YearMonth ym = promptYearMonth(dialog);
            if (ym == null) return;
            double gross = payrollService.calculateMonthlySalary(emp, ym);
            JOptionPane.showMessageDialog(dialog, String.format("Gross Salary for %s in %s: %.2f",
                    emp.getFullName(), ym, gross));
        });

        netEmpBtn.addActionListener(e -> {
            Employee emp = promptEmployeeNumber(dialog);
            if (emp == null) return;
            YearMonth ym = promptYearMonth(dialog);
            if (ym == null) return;
            double net = payrollService.calculateNetSalary(emp, ym);
            JOptionPane.showMessageDialog(dialog, String.format("Net Salary for %s in %s: %.2f",
                    emp.getFullName(), ym, net));
        });

        closeBtn.addActionListener(e -> dialog.dispose());

        dialog.setVisible(true);
    }

    private void exportPayrollReport(Component parent) {
        YearMonth ym = promptYearMonth(parent);
        if (ym == null) return;

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select CSV File to Save Payroll Report");
        fileChooser.setSelectedFile(new File("payroll_report_" + ym + ".csv"));

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try {
                payrollService.exportPayrollReportToCSV(employees, ym, fileToSave.getAbsolutePath());
                JOptionPane.showMessageDialog(this, "Payroll report exported to:\n" + fileToSave.getAbsolutePath());
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error exporting CSV: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Helper dialogs

    private YearMonth promptYearMonth(Component parent) {
        String input = JOptionPane.showInputDialog(parent, "Enter month and year (yyyy-MM):");
        if (input == null) return null;
        try {
            return YearMonth.parse(input.trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parent, "Invalid format. Use yyyy-MM.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    private Employee promptEmployeeNumber(Component parent) {
        String input = JOptionPane.showInputDialog(parent, "Enter employee number:");
        if (input == null) return null;
        try {
            int empNum = Integer.parseInt(input.trim());
            Employee emp = employeeService.findEmployeeByNumber(empNum);
            if (emp == null) {
                JOptionPane.showMessageDialog(parent, "Employee not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            return emp;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(parent, "Invalid employee number.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    private void showLongText(Component parent, String title, String content) {
        JTextArea area = new JTextArea(20, 50);
        area.setText(content);
        area.setEditable(false);
        area.setFont(new Font("Consolas", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(area);

        JOptionPane.showMessageDialog(parent, scrollPane, title, JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainGUI().setVisible(true));
    }
}
