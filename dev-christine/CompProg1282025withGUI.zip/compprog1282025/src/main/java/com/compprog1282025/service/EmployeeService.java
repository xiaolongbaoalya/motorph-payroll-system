package com.compprog1282025.service;

import com.compprog1282025.model.Employee;

import java.util.List;

public class EmployeeService {

    private final List<Employee> employeeList;

    public EmployeeService(List<Employee> employeeList) {
        this.employeeList = employeeList;
    }

    public void printAllEmployeeData() {
        for (Employee e : employeeList) {
            System.out.println(e);  // This calls Employee.toString()
            System.out.println(" - ----------");
        }
    }

    public List<Employee> getAllEmployees() {
        return employeeList;
    }

    public Employee findEmployeeByNumber(int employeeNumber) {
        return employeeList.stream()
                .filter(e -> e.getEmployeeNumber() == employeeNumber)
                .findFirst()
                .orElse(null);
    }

}
