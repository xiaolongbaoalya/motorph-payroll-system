package com.compprog1282025.util;

import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.compprog1282025.model.Employee;

public class CSVWriter {

    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    public static void appendEmployeeToCSV(Employee employee, String filepath) throws IOException {
        try (com.opencsv.CSVWriter writer = new com.opencsv.CSVWriter(new FileWriter(filepath, true))) {
            String[] record = new String[] {
                String.valueOf(employee.getEmployeeNumber()),
                employee.getLastName(),
                employee.getFirstName(),
                employee.getBirthday().format(dateFormatter),
                employee.getContact().getAddress(),
                employee.getContact().getPhoneNumber(),
                employee.getGovernmentID().getSss(),
                employee.getGovernmentID().getPhilhealth(),
                employee.getGovernmentID().getTin(),
                employee.getGovernmentID().getPagibig(),
                employee.getStatus(),
                employee.getPosition().getPosition(),
                employee.getPosition().getSupervisor() != null ? employee.getPosition().getSupervisor().getFullName() : "",
                formatDouble(employee.getCompensation().getBasicSalary()),
                formatDouble(employee.getCompensation().getRiceSubsidy()),
                formatDouble(employee.getCompensation().getPhoneAllowance()),
                formatDouble(employee.getCompensation().getClothingAllowance()),
                formatDouble(employee.getCompensation().getSemiGross()),
                formatDouble(employee.getCompensation().getHourlyRate())
            };

            writer.writeNext(record);
        }
    }

    private static String formatDouble(double value) {
        return String.format("\"%,.0f\"", value); // Format as quoted string like "90,000"
    }

    public static void updateEmployeeInCSV(Employee updatedEmployee, String filepath) throws IOException {
        List<Employee> allEmployees;
        try {
            allEmployees = CSVReader.readEmployeesFromCSV(filepath);
        } catch (Exception e) {
            throw new IOException("Failed to read employees from CSV", e);
        }

        for (int i = 0; i < allEmployees.size(); i++) {
            if (allEmployees.get(i).getEmployeeNumber() == updatedEmployee.getEmployeeNumber()) {
                allEmployees.set(i, updatedEmployee);
                break;
            }
        }

        writeAllEmployeesToCSV(allEmployees, filepath);
    }

    public static void deleteEmployeeFromCSV(int employeeNumber, String filepath) throws IOException {
        List<Employee> allEmployees;
        try {
            allEmployees = CSVReader.readEmployeesFromCSV(filepath);
        } catch (Exception e) {
            throw new IOException("Failed to read employees from CSV", e);
        }
        allEmployees.removeIf(emp -> emp.getEmployeeNumber() == employeeNumber);
    
        writeAllEmployeesToCSV(allEmployees, filepath);
        }

    public static void writeAllEmployeesToCSV(List<Employee> employees, String filepath) throws IOException {
        try (com.opencsv.CSVWriter writer = new com.opencsv.CSVWriter(new FileWriter(filepath))) {
            // Write header
            writer.writeNext(new String[]{
                "Employee #", "Last Name", "First Name", "Birthday", "Address", "Phone",
                "SSS #", "Philhealth #", "TIN #", "Pag-ibig #", "Status", "Position", "Supervisor",
                "Basic Salary", "Rice Subsidy", "Phone Allowance", "Clothing Allowance",
                "Gross Semi-monthly Rate", "Hourly Rate"
            });

            for (Employee emp : employees) {
                writer.writeNext(new String[]{
                    String.valueOf(emp.getEmployeeNumber()),
                    emp.getLastName(),
                    emp.getFirstName(),
                    emp.getBirthday().format(DateTimeFormatter.ofPattern("MM/dd/yyyy")),
                    emp.getContact().getAddress(),
                    emp.getContact().getPhoneNumber(),
                    emp.getGovernmentID().getSss(),
                    emp.getGovernmentID().getPhilhealth(),
                    emp.getGovernmentID().getTin(),
                    emp.getGovernmentID().getPagibig(),
                    emp.getStatus(),
                    emp.getPosition().getPosition(),
                    emp.getPosition().getSupervisor() != null ? emp.getPosition().getSupervisor().getFullName() : "",
                    String.valueOf(emp.getCompensation().getBasicSalary()),
                    String.valueOf(emp.getCompensation().getRiceSubsidy()),
                    String.valueOf(emp.getCompensation().getPhoneAllowance()),
                    String.valueOf(emp.getCompensation().getClothingAllowance()),
                    String.valueOf(emp.getCompensation().getSemiGross()),
                    String.valueOf(emp.getCompensation().getHourlyRate())
                });
            }
        }
    }


}
