package com.compprog1282025.service;

import com.compprog1282025.model.Attendance;
import com.compprog1282025.model.Employee;

import java.time.YearMonth;
import java.time.Duration;
import java.util.List;

public class AttendanceService {

    private final List<Attendance> attendanceRecords;

    public AttendanceService(List<Attendance> attendanceRecords) {
        this.attendanceRecords = attendanceRecords;
    }

    /**
     * Calculate the total hours worked by the specified employee during the given month.
     * 
     * @param employee the employee whose attendance to calculate
     * @param month the YearMonth to filter attendance records
     * @return total hours worked (fractional hours allowed)
     */
    public double calculateMonthlyHours(Employee employee, YearMonth month) {
        return attendanceRecords.stream()
                .filter(a -> a.getEmployee().equals(employee))
                .filter(a -> YearMonth.from(a.getDate()).equals(month))
                .mapToDouble(a -> {
                    Duration duration = Duration.between(a.getTimeIn(), a.getTimeOut());
                    // Defensive: if timeOut is before timeIn (should not happen), return 0
                    return duration.isNegative() ? 0 : duration.toMinutes() / 60.0;
                })
                .sum();
    }
}
